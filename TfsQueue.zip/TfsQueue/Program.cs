﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.VisualStudio.Services.Client;
using Microsoft.TeamFoundation.SourceControl.WebApi;
using Microsoft.VisualStudio.Services.WebApi;

namespace TfsQueue
{
    class Program
    {
        static void Main(string[] args)
        {

            const String c_collectionUri = "https://judavi.visualstudio.com";
            const String c_projectName = "buildqueuetest";


            Uri accountUri = new Uri(c_collectionUri);

            VssBasicCredential credentials = new VssBasicCredential(string.Empty, "securitytokenhere");
            // Connect to VSTS
            VssConnection connection = new VssConnection(accountUri, credentials);

            // Get a GitHttpClient to talk to the Git endpoints
            GitHttpClient gitClient = connection.GetClient<GitHttpClient>();

            // Get data about a specific repository
            var repo = gitClient.GetRepositoryAsync(c_projectName, c_projectName).Result;

            string peep = "";
        }
    }
}
